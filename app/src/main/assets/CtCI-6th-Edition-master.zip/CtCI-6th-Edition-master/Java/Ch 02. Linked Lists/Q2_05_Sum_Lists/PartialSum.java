package Q2_05_Sum_Lists;

import CtCILibrary.LinkedListNode;

public class PartialSum {
	public LinkedListNode sum = null;
	public int carry = 0;
}
