package Q7_02_Call_Center;

public class Caller {
	private String name;
	private int userId;
	public Caller(int id, String nm) {
		name = nm;
		userId = id;
	}
}
